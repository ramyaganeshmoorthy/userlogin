Run below command for installing node dependencies
>npm install

Run the application by below command
>node app.js


Hi! there are 3 main pages in this application.
- index.html : For Entering the user information
> URL: http://localhost:3000/index.html

- success.html: Apperars on succesful storage of user information in database
> URL: http://localhost:3000/success.html
- list.html: To list and export user details
>URL: http://localhost:3000/list.html
